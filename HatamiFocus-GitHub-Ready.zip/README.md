# 🔵 Hatami Focus Pro

برنامه ویندوزی مطالعه Hatami Edu با تمرکز روی یک محیط یکپارچه برای مطالعه، ویدئو، PDF و تست.

## امکانات
- داشبورد
- تایمر مطالعه 25 / 50 / 90 دقیقه
- ثبت جلسات مطالعه و هدف روزانه
- Video Player داخلی
- PDF Reader داخلی با WebView2
- صفحه آزمون چهارگزینه‌ای
- بارگذاری آزمون JSON
- محاسبه درست، غلط، نزده و درصد
- ذخیره نتایج و آمار
- تنظیمات
- GitHub Actions
- انتشار خودکار Artifact ویندوز

## ساخت EXE روی کامپیوتر
```powershell
dotnet restore HatamiFocus/HatamiFocus.csproj
dotnet publish HatamiFocus/HatamiFocus.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o publish
```

فایل خروجی در پوشه `publish` قرار می‌گیرد.

## ساخت EXE با GitHub
1. این پروژه را داخل یک Repository آپلود کنید.
2. به تب **Actions** بروید.
3. Workflow با نام **Build Hatami Focus Pro** را اجرا کنید.
4. پس از پایان Build، از بخش **Artifacts** فایل `HatamiFocus-Pro-Windows` را دریافت کنید.

## ساخت Release
برای انتشار رسمی:
- یک Tag مثل `v2.0.0` بسازید.
- Workflow انتشار را اجرا کنید.
- فایل ZIP/EXE خروجی را در Release قرار دهید.

## فرمت آزمون JSON
```json
[
  {
    "Text": "متن سؤال",
    "Options": ["گزینه ۱","گزینه ۲","گزینه ۳","گزینه ۴"],
    "CorrectIndex": 1,
    "Explanation": "توضیح پاسخ"
  }
]
```

## نکته PDF
PDF Reader از Microsoft WebView2 استفاده می‌کند. روی Windows 10/11 معمولاً WebView2 Runtime موجود است؛ اگر نبود باید Runtime نصب شود.

## Tech
C# / .NET 8 / WPF / WebView2
