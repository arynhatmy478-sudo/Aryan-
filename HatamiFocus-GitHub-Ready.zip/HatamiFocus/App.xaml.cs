using System.Windows;
namespace HatamiFocus;
public partial class App : Application { }
