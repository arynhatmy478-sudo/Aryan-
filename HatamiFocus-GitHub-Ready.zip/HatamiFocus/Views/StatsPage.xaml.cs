using System.Windows.Controls;
using HatamiFocus.Services;
namespace HatamiFocus.Views;
public partial class StatsPage:Page{
 public StatsPage(){InitializeComponent();var st=new StorageService();var sr=st.StudyRecords();var q=st.QuizResults();Study.Text=$"{sr.Sum(x=>x.Minutes)} دقیقه";Tests.Text=q.Count.ToString();Avg.Text=q.Count==0?"—":$"{q.Average(x=>x.Percent):0.0}%";foreach(var x in q.OrderByDescending(x=>x.Date).Take(20))List.Items.Add($"{x.Date:yyyy/MM/dd HH:mm}    {x.Percent:0.0}%    درست {x.Correct} | غلط {x.Wrong} | نزده {x.Blank}");}
}
