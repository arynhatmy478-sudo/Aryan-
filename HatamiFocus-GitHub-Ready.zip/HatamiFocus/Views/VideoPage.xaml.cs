using System.Windows;
using Microsoft.Win32;
namespace HatamiFocus.Views;
public partial class VideoPage:Page{
 public VideoPage(){InitializeComponent();}
 void Open(object s,RoutedEventArgs e){var d=new OpenFileDialog{Filter="Video|*.mp4;*.wmv;*.avi;*.mov|All|*.*"};if(d.ShowDialog()==true){Player.Source=new Uri(d.FileName);Player.Play();}}
 void Play(object s,RoutedEventArgs e)=>Player.Play(); void Pause(object s,RoutedEventArgs e)=>Player.Pause(); void Stop(object s,RoutedEventArgs e)=>Player.Stop();
}
