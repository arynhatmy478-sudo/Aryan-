using System.Windows;
using Microsoft.Win32;
namespace HatamiFocus.Views;
public partial class PdfPage:Page{
 public PdfPage(){InitializeComponent();Loaded+=async(_,_)=>await Browser.EnsureCoreWebView2Async();}
 async void Open(object s,RoutedEventArgs e){var d=new OpenFileDialog{Filter="PDF|*.pdf"};if(d.ShowDialog()==true){await Browser.EnsureCoreWebView2Async();Browser.Source=new Uri(d.FileName);}}
}
