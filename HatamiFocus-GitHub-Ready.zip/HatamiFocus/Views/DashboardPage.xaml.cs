using System.Windows;
using System.Windows.Controls;
using HatamiFocus.Services;
namespace HatamiFocus.Views;
public partial class DashboardPage:Page{
 readonly StorageService st=new();
 public DashboardPage(){InitializeComponent();Refresh();}
 void Refresh(){var a=st.StudyRecords().Where(x=>x.Date.Date==DateTime.Today).Sum(x=>x.Minutes);var q=st.QuizResults();Study.Text=$"{a} دقیقه";Tests.Text=q.Count.ToString();Avg.Text=q.Count==0?"—":$"{q.Average(x=>x.Percent):0}%";}
 void StudyClick(object s,RoutedEventArgs e)=>NavigationService.Navigate(new StudyPage());
 void VideoClick(object s,RoutedEventArgs e)=>NavigationService.Navigate(new VideoPage());
 void PdfClick(object s,RoutedEventArgs e)=>NavigationService.Navigate(new PdfPage());
 void QuizClick(object s,RoutedEventArgs e)=>NavigationService.Navigate(new QuizPage());
}
