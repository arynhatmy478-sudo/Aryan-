using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using HatamiFocus.Models;
using HatamiFocus.Services;
namespace HatamiFocus.Views;
public partial class QuizPage:Page{
 List<QuizQuestion> q=new(); int[] ans=Array.Empty<int>(); int i; readonly StorageService st=new();
 public QuizPage(){InitializeComponent();BuiltIn();}
 void BuiltIn(){q=new(){new QuizQuestion{Text="کدام اندامک محل اصلی تولید ATP است؟",Options=new[]{"هسته","میتوکندری","ریبوزوم","دستگاه گلژی"},CorrectIndex=1,Explanation="میتوکندری محل اصلی تولید ATP در تنفس هوازی است."},new QuizQuestion{Text="در قانون اهم، اگر مقاومت دو برابر شود و ولتاژ ثابت بماند، جریان چه تغییری می‌کند؟",Options=new[]{"دو برابر","نصف","ثابت","چهار برابر"},CorrectIndex=1,Explanation="I=V/R، پس جریان نصف می‌شود."}};ans=Enumerable.Repeat(-1,q.Count).ToArray();Show();}
 void Load(object s,RoutedEventArgs e){var d=new OpenFileDialog{Filter="Quiz JSON|*.json"};if(d.ShowDialog()==true)try{q=JsonSerializer.Deserialize<List<QuizQuestion>>(File.ReadAllText(d.FileName))??new();ans=Enumerable.Repeat(-1,q.Count).ToArray();i=0;Show();}catch{MessageBox.Show("فایل JSON معتبر نیست.");}}
 void Show(){if(q.Count==0)return;var x=q[i];Counter.Text=$"سؤال {i+1} از {q.Count}";Question.Text=x.Text;A.Content="۱) "+x.Options.ElementAtOrDefault(0);B.Content="۲) "+x.Options.ElementAtOrDefault(1);C.Content="۳) "+x.Options.ElementAtOrDefault(2);D.Content="۴) "+x.Options.ElementAtOrDefault(3);A.IsChecked=ans[i]==0;B.IsChecked=ans[i]==1;C.IsChecked=ans[i]==2;D.IsChecked=ans[i]==3;Explanation.Text="";}
 void Answer(object s,RoutedEventArgs e){if(A.IsChecked==true)ans[i]=0;else if(B.IsChecked==true)ans[i]=1;else if(C.IsChecked==true)ans[i]=2;else if(D.IsChecked==true)ans[i]=3;}
 void Prev(object s,RoutedEventArgs e){if(i>0){i--;Show();}} void Next(object s,RoutedEventArgs e){if(i<q.Count-1){i++;Show();}}
 void Finish(object s,RoutedEventArgs e){int correct=0,blank=0;for(int n=0;n<q.Count;n++){if(ans[n]<0)blank++;else if(ans[n]==q[n].CorrectIndex)correct++;}int wrong=q.Count-correct-blank;double pct=q.Count==0?0:correct*100.0/q.Count;var list=st.QuizResults();list.Add(new QuizResult{Total=q.Count,Correct=correct,Wrong=wrong,Blank=blank,Percent=pct});st.SaveQuiz(list);MessageBox.Show($"درست: {correct}\nغلط: {wrong}\nنزده: {blank}\nدرصد: {pct:0.0}%","نتیجه");}
}
