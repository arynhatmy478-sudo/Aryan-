using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using HatamiFocus.Models;
using HatamiFocus.Services;
namespace HatamiFocus.Views;
public partial class StudyPage:Page{
 readonly DispatcherTimer timer=new(){Interval=TimeSpan.FromSeconds(1)};
 readonly StorageService st=new(); int seconds=1500, selectedMinutes=25;
 public StudyPage(){InitializeComponent();timer.Tick+=Tick;Update();}
 void Set(int m){selectedMinutes=m;if(!timer.IsEnabled){seconds=m*60;Update();}}
 void P25(object s,RoutedEventArgs e)=>Set(25); void P50(object s,RoutedEventArgs e)=>Set(50); void P90(object s,RoutedEventArgs e)=>Set(90);
 void Start(object s,RoutedEventArgs e)=>timer.Start(); void Pause(object s,RoutedEventArgs e)=>timer.Stop();
 void Reset(object s,RoutedEventArgs e){timer.Stop();seconds=selectedMinutes*60;Update();}
 void Tick(object? s,EventArgs e){seconds--;Update();if(seconds<=0){timer.Stop();var list=st.StudyRecords();list.Add(new StudyRecord{Subject=(Subject.SelectedItem as ComboBoxItem)?.Content?.ToString()??"عمومی",Minutes=selectedMinutes});st.SaveStudy(list);MessageBox.Show("جلسه مطالعه با موفقیت ثبت شد.","Hatami Focus");seconds=selectedMinutes*60;Update();}}
 void Update()=>Timer.Text=$"{Math.Max(0,seconds/60):00}:{Math.Max(0,seconds%60):00}";
}
