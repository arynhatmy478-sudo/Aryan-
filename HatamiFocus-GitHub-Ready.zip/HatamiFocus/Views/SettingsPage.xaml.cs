using System.Windows;
using HatamiFocus.Services;
namespace HatamiFocus.Views;
public partial class SettingsPage:Page{
 readonly StorageService st=new();
 public SettingsPage(){InitializeComponent();var s=st.Settings();Goal.Text=s.DailyGoalMinutes.ToString();Notify.IsChecked=s.Notifications;}
 void Save(object s,RoutedEventArgs e){var x=st.Settings();if(int.TryParse(Goal.Text,out var g))x.DailyGoalMinutes=Math.Max(1,g);x.Notifications=Notify.IsChecked==true;st.SaveSettings(x);MessageBox.Show("تنظیمات ذخیره شد.");}
}
