namespace HatamiFocus.Models;
public class QuizResult {
 public DateTime Date {get;set;}=DateTime.Now;
 public string Title {get;set;}="آزمون";
 public int Total {get;set;}
 public int Correct {get;set;}
 public int Wrong {get;set;}
 public int Blank {get;set;}
 public double Percent {get;set;}
}
