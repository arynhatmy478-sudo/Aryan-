namespace HatamiFocus.Models;
public class StudyRecord {
 public DateTime Date {get;set;}=DateTime.Now;
 public string Subject {get;set;}="";
 public int Minutes {get;set;}
}
