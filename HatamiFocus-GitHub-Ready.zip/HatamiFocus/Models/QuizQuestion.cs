namespace HatamiFocus.Models;
public class QuizQuestion {
 public string Text {get;set;}="";
 public string[] Options {get;set;}=new string[4];
 public int CorrectIndex {get;set;}
 public string Explanation {get;set;}="";
}
