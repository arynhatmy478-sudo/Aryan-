namespace HatamiFocus.Models;
public class AppSettings {
 public int DailyGoalMinutes {get;set;}=240;
 public bool StartWithWindows {get;set;}=false;
 public bool Notifications {get;set;}=true;
}
