using System.Text.Json;
using HatamiFocus.Models;
namespace HatamiFocus.Services;
public class StorageService {
 readonly string dir=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"HatamiEdu","HatamiFocus");
 string Q=>Path.Combine(dir,"quiz-results.json");
 string S=>Path.Combine(dir,"study-records.json");
 string C=>Path.Combine(dir,"settings.json");
 readonly JsonSerializerOptions o=new(){WriteIndented=true};
 public StorageService(){Directory.CreateDirectory(dir);}
 T Load<T>(string p,T fallback){try{return File.Exists(p)?JsonSerializer.Deserialize<T>(File.ReadAllText(p))??fallback:fallback;}catch{return fallback;}}
 void Save<T>(string p,T x)=>File.WriteAllText(p,JsonSerializer.Serialize(x,o));
 public List<QuizResult> QuizResults()=>Load(Q,new List<QuizResult>());
 public List<StudyRecord> StudyRecords()=>Load(S,new List<StudyRecord>());
 public AppSettings Settings()=>Load(C,new AppSettings());
 public void SaveQuiz(List<QuizResult>x)=>Save(Q,x);
 public void SaveStudy(List<StudyRecord>x)=>Save(S,x);
 public void SaveSettings(AppSettings x)=>Save(C,x);
}
