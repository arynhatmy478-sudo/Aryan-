using System.Windows;
using HatamiFocus.Views;
namespace HatamiFocus;
public partial class MainWindow : Window {
 public MainWindow(){InitializeComponent(); Navigate<DashboardPage>();}
 void Navigate<T>() where T:Page,new()=>ContentFrame.Navigate(new T());
 void Dash(object s,RoutedEventArgs e)=>Navigate<DashboardPage>();
 void Study(object s,RoutedEventArgs e)=>Navigate<StudyPage>();
 void Video(object s,RoutedEventArgs e)=>Navigate<VideoPage>();
 void Pdf(object s,RoutedEventArgs e)=>Navigate<PdfPage>();
 void Quiz(object s,RoutedEventArgs e)=>Navigate<QuizPage>();
 void Stats(object s,RoutedEventArgs e)=>Navigate<StatsPage>();
 void Settings(object s,RoutedEventArgs e)=>Navigate<SettingsPage>();
}
